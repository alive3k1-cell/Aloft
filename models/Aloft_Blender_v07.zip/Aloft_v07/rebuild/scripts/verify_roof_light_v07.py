import bpy,bmesh,json,hashlib,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1];O=R/'model/v07'
report={'version':'V07','scope':'Geometry, source registration, roundtrip and visual controls; no photometric or installation approval'}
def correction_checks(objects):
 byname={ob.name:ob for ob in objects}
 slab=byname['F01_GROUND_TERRACE_SLAB'];zs=[(slab.matrix_world@v.co).z for v in slab.data.vertices]
 assert abs(max(zs))<.00001 and abs(min(zs)+.25)<.00001
 assert not any('LOWER_BALCONY' in ob.name or 'ENTRANCE_ROOF_RAIL' in ob.name for ob in objects)
 rail=byname['F01_BALCONY_RAILS'];assert min((rail.matrix_world@v.co).z for v in rail.data.vertices)>30
 env=byname['BUILDING_WING_ENVELOPE_V07']
 def surface_material(y):
  origin=Vector((-10,y,25));direction=Vector((1,0,0));inv=env.matrix_world.inverted();ok,pt,normal,idx=env.ray_cast(inv@origin,inv.to_3x3()@direction);assert ok
  return env.data.materials[env.data.polygons[idx].material_index].name
 assert surface_material(17.3).startswith('MAT_GLASS')
 inv=env.matrix_world.inverted();ok,pt,normal,idx=env.ray_cast(inv@Vector((3,-10,25)),inv.to_3x3()@Vector((0,1,0)));assert ok
 assert env.data.materials[env.data.polygons[idx].material_index].name.startswith('MAT_GLASS')
 def material_at(origin,direction):
  ok,pt,normal,idx=env.ray_cast(inv@Vector(origin),inv.to_3x3()@Vector(direction));assert ok
  return env.data.materials[env.data.polygons[idx].material_index].name
 assert material_at((6.1,100,42.3),(0,-1,0)).startswith('MAT_GLASS')
 assert material_at((3.3,100,38),(0,-1,0)).startswith('MAT_GLASS')
 assert not material_at((.55,100,38),(0,-1,0)).startswith('MAT_GLASS')
 assert material_at((4.3,-50,25),(0,1,0)).startswith('MAT_GLASS')
 grey_area=0;grey_levels=set()
 for p in env.data.polygons:
  ps=[env.matrix_world@env.data.vertices[i].co for i in p.vertices]
  c=sum(ps,Vector())/len(ps)
  if 19.0<c.x<26.95 and 10<c.z<44.85 and c.y>29.5 and abs(p.normal.y)>.9:
   mat=env.data.materials[p.material_index].name
   if mat.startswith('MAT_FACADE_GREY_'):grey_area+=p.area;grey_levels.add(int(c.z/3.3))
 assert grey_area>40 and len(grey_levels)>=7,(grey_area,grey_levels)
 columns=[ob for ob in objects if ob.name.startswith('ROOF_TERRACE_COLUMN_')]
 support=[env,byname['ROOF_TERRACE_SUPPORTING_DECK']];roof=byname['ROOF_CANTILEVER_WITH_OPENING']
 for col in columns:
  pts=[col.matrix_world@v.co for v in col.data.vertices];base=min(p.z for p in pts);top=max(p.z for p in pts);cx=(min(p.x for p in pts)+max(p.x for p in pts))/2;cy=(min(p.y for p in pts)+max(p.y for p in pts))/2
  def touches(obs,z,direction):
   for ob in obs:
    inv=ob.matrix_world.inverted();origin=Vector((cx,cy,z));direct=Vector((0,0,direction));ok,pt,normal,idx=ob.ray_cast(inv@origin,inv.to_3x3()@direct)
    if ok and ((ob.matrix_world@pt)-origin).length<.011:return True
   return False
  assert touches(support,base+.005,-1),('unsupported column',col.name,base,cx,cy)
  assert touches([roof,byname['ROOF_CONTINUOUS_SOFFIT']],top-.005,1),('column misses roof',col.name)
 far_glass_area=0.;far_orange_area=0.
 for p in env.data.polygons:
  ps=[env.matrix_world@env.data.vertices[i].co for i in p.vertices]
  if all(37.4<q.x<37.7 and q.y<13.85 and 9.69<q.z<43.66 for q in ps):
   mat=env.data.materials[p.material_index].name
   if mat.startswith('MAT_GLASS'):far_glass_area+=p.area
   if mat.startswith('MAT_TERRACOTTA'):far_orange_area+=p.area
 assert far_glass_area>50 and far_orange_area>50,(far_glass_area,far_orange_area)
 assert 'F01_SHALLOW_WINDOW_GRID' in byname and 'F04_EDGE_RECESSED_LOGGIA' in byname
 assert 'F02_UPPER_BALCONY_TERRACE' in byname and 'F01_BALCONY_RAILS_GLASS' in byname
 return {'ground_terrace_top_m':0.0,'upper_front_balcony_rows_only':[30.0,33.3],'west_end_curtain_preserved':True,'rear_annotation_glazed':True,'upper_right_window_full_height':True,'under_terrace_discrete_windows':True,'grey_panel_pattern_model_area_m2':round(grey_area,3),'grey_pattern_height_bands':len(grey_levels),'columns_supported_at_base_and_touch_roof':len(columns)}
def hit(objects,xy):
 origin=Vector((*xy,100));direction=Vector((0,0,-1))
 for ob in objects:
  inv=ob.matrix_world.inverted()
  if ob.ray_cast(inv@origin,inv.to_3x3()@direction)[0]:return True
 return False
def checks(objects):
 primary=[ob for ob in objects if ob.name.startswith('BUILDING_WING_ENVELOPE')]
 assert len(primary)==1
 bm=bmesh.new();bm.from_mesh(primary[0].data)
 # GLB may split vertices at material/normal boundaries: weld numerical duplicates for topology check.
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000002)
 non=sum(not e.is_manifold for e in bm.edges);bm.free();assert non==0,non
 assert not hit(objects,(20,5));assert hit(primary,(45,5));assert hit(primary,(25,20))
 return {'primary_nonmanifold_edges_after_position_weld':non,'cutout_empty_at_20_5':True,'both_wings_present':True,'mesh_objects':len(objects)}

old=json.load(open(R/'model/v06/geometry_v06.json'));new=json.load(open(O/'geometry_v07.json'))
removed=set(new['metadata']['roof_removed_old_objects']);byname={q['name']:q for q in new['objects']};retained=0
for q in old['objects']:
 if q['name'] in removed:continue
 expected=dict(q);expected['name']=q['name'].replace('V06','V07')
 assert expected==byname[expected['name']],expected['name'];retained+=1
assert retained==71
report['accepted_V06_objects_preserved_exactly']=retained
L=json.load(open(O/'lighting_geometry.json'));P=json.load(open(O/'pixel_map.json'))
ids={q['id'] for q in L['segments']};assert len(ids)==61 and len(P)==1834 and len({p['pixel_id'] for p in P})==1834
assert not any(q['cad_handle']=='32BF51' for q in L['segments'])
assert all(q['original_overlay_aliases'] for q in L['segments'])
for q in L['segments']:
 assert abs(sum(math.dist(a,b) for a,b in zip(q['points_m'],q['points_m'][1:]))-q['cad_length_m'])<1e-7
 assert sum(p['segment_id']==q['id'] for p in P)==q['preview_pixel_count']
total=sum(q['cad_length_m'] for q in L['segments']);assert abs(total-305.6743763630887)<.000001
report['CAD_lines']={'unique_segments':61,'cad_length_m':total,'preview_pixels':len(P),'duplicated_copy_excluded':'32BF51','all_segments_matched_original_overlays':True}
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_roof_light_v07.blend'))
arch=[ob for ob in bpy.data.collections['ALMAZOV_ARCHITECTURE_V07'].objects if ob.type=='MESH']
report['blend_reopened']=checks(arch);report['accepted_facade_checks']=correction_checks(arch)
assert not any(im.source=='FILE' and not im.packed_file for im in bpy.data.images)
report['external_textures_required']=False
curves=[ob for ob in bpy.context.scene.objects if ob.name.startswith('NEON_SEG_')]
assert len(curves)==61 and {ob['segment_id'] for ob in curves}==ids
for ob in curves:
 q=next(q for q in L['segments'] if q['id']==ob['segment_id']);ps=ob.data.splines[0].points
 assert len(ps)==len(q['points_m'])
 assert all(math.dist(tuple(p.co)[:3],ref)<.00001 for p,ref in zip(ps,q['points_m']))
 if q['group']=='POOL':
  assert q['emission_axis']==[0,0,-1]
  for p in q['points_m']:
   roof=bpy.data.objects['ROOF_CONTINUOUS_SOFFIT'];inv=roof.matrix_world.inverted();ok,pt,normal,idx=roof.ray_cast(inv@Vector(p),inv.to_3x3()@Vector((0,0,1)))
   assert ok and 0<(roof.matrix_world@pt).z-p[2]<.02
spill=[ob for ob in bpy.context.scene.objects if ob.type=='LIGHT' and ob.name.startswith('SPILL_')];assert len(spill)==11
for ob in spill:
 if ob.name.startswith('SPILL_POOL_'):assert (ob.matrix_world.to_quaternion()@Vector((0,0,-1))).dot(Vector((0,0,-1)))>.999
report['pool_source_curves_on_soffit_and_spill_downward']=True
c=bpy.data.objects['LIGHT_CONTROLS'];saved={k:c[k] for k in c.keys()}
def update():
 c.update_tag();bpy.context.scene.frame_set(bpy.context.scene.frame_current);bpy.context.view_layer.update()
def strength(g):return bpy.data.materials['NEON_RGBW_'+g].node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value
def color(g):return tuple(bpy.data.materials['NEON_RGBW_'+g].node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value)[:3]
c['MASTER']=0.;update();assert all(abs(strength(g))<1e-7 for g in L['summary'])
assert all(abs(ob.data.energy)<1e-7 for ob in spill)
c['MASTER']=.65;c['UPPER_FRAME_LEVEL']=.8;update();v=strength('UPPER_FRAME');col=color('UPPER_FRAME')
c['ENVIRONMENT']=2.;update();assert abs(strength('UPPER_FRAME')-v)<1e-7 and color('UPPER_FRAME')==col
for ch in 'RGB':c['UPPER_FRAME_'+ch]=0.
c['UPPER_FRAME_W']=1.;update();assert all(abs(v-1)<1e-7 for v in color('UPPER_FRAME'))
c['BLOOM']=0.;c['EXPOSURE']=.7;update()
add=next(n for n in bpy.context.scene.node_tree.nodes if n.type=='MIX_RGB');assert abs(add.inputs[0].default_value)<1e-7
assert abs(bpy.context.scene.view_settings.exposure-.7)<1e-6
for k,v in saved.items():c[k]=v
update()
assert 'POOL_TEST' in bpy.data.texts['LIGHT_PRESETS.py'].as_string()
report['controls']={'MASTER_zero_disables_emission_and_spill':True,'environment_independent_from_neon':True,'independent_W_neutral_preview':True,'bloom_zero_disables_glow':True,'exposure_driver':True}
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(O/'Aloft_roof_light_v07.glb'))
obs=[ob for ob in bpy.context.scene.objects if ob.type=='MESH']
light=[ob for ob in obs if 'segment_id' in ob];assert len(light)==61 and {ob['segment_id'] for ob in light}==ids
architecture=[ob for ob in obs if not ob.name.startswith(('NEON_SEG_','CHANNELS_'))]
report['glb_reimported']=checks(architecture);report['glb_accepted_facade_checks']=correction_checks(architecture)
assert not any(ob.name.startswith(('PRESENTATION_','POOL_FLOOR_RECEIVER','SPILL_')) for ob in obs)
report['glb_source_neon_meshes']=len(light);report['glb_excludes_site_and_temporary_pool_receiver']=True
repo=Path('/workspace/Aloft');report['source_dwg_sha256']={}
for name,expected in {'codexF.dwg':'7078aa245939e2f60e2f431a84854e445d95cf6ea0c8a66275ba50f95cc6f84e','Геометрия.dwg':'77db0648bb8480c9acabfb5631dbc7e70377071d855996b0e97ae782498addf0'}.items():
 digest=hashlib.sha256((repo/name).read_bytes()).hexdigest();assert digest==expected;report['source_dwg_sha256'][name]=digest
(O/'validation_v07.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
