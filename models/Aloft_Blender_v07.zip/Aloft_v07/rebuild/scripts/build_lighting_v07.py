import bpy,json,math,time,sys
from pathlib import Path
from mathutils import Vector,Matrix
O=Path(__file__).resolve().parents[1]/'model/v07';L=json.load(open(O/'lighting_geometry.json'));D=json.load(open(O/'geometry_v07.json'))
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_visual_v07.blend'));s=bpy.context.scene
s['accepted_architecture']='V06; facade mesh arrays frozen. Only roof reconstructed under explicit user authorization.'
s['lighting_status']='First source-registered RGBW preview. Artist-controlled radiance/spill, not lux/IES or equipment design.'
root=bpy.data.collections.new('RGBW_SOURCE_LINES_V07');s.collection.children.link(root);groups={}
for g in ['ROOF','BIG_FRAME','UPPER_FRAME','POOL']:
 c=bpy.data.collections.new('LIGHT_'+g);root.children.link(c);groups[g]=c
ctrl=bpy.data.objects.new('LIGHT_CONTROLS',None);root.objects.link(ctrl);ctrl.empty_display_type='PLAIN_AXES';ctrl.empty_display_size=1.;ctrl.location=(26,15,50)
def prop(k,val,lo=0,hi=1,description=''):
 ctrl[k]=val;ctrl.id_properties_ui(k).update(min=lo,max=hi,soft_min=lo,soft_max=hi,description=description)
for k,v,a,b,d in [('MASTER',.65,0,1,'Общая яркость неона и связанного локального света'),('ENVIRONMENT',1.,0,3,'Только небо, солнечный/общий заполняющий свет'),('EXPOSURE',0.,-5,5,'Только экспозиция кадра'),('BLOOM',.16,0,1,'Мягкое свечение; 0 полностью исключает вклад'),('SPILL',1.,0,3,'Локальный отражённый свет, визуальная настройка'),('DAYLIGHT',0.,0,1,'0 — сумерки, 1 — дневная проверка кровли')]:prop(k,v,a,b,d)
colors={'ROOF':(.9,.015,.5,0),'BIG_FRAME':(.015,.8,.55,0),'UPPER_FRAME':(.5,.9,.035,0),'POOL':(0,0,0,0)}
levels={'ROOF':.85,'BIG_FRAME':.8,'UPPER_FRAME':.8,'POOL':0.}
for g in groups:
 for ch,v in zip('RGBW',colors[g]):prop(g+'_'+ch,v,description=g+' независимый канал '+ch)
 prop(g+'_LEVEL',levels[g],description='Яркость группы '+g)
ctrl['CAD_total_length_m']=sum(q['cad_length_m'] for q in L['segments']);ctrl['preview_pixel_count']=1834;ctrl['preview_profile']='Four scalar RGBW channels for visualization; no DMX bit depth, ports or direction assumed.'
def driver(target,attr,index,expr,props):
 fc=target.driver_add(attr,index) if index is not None else target.driver_add(attr);d=fc.driver;d.type='SCRIPTED';d.expression=expr
 for name,key in props.items():
  v=d.variables.new();v.name=name;v.type='SINGLE_PROP';v.targets[0].id=ctrl;v.targets[0].data_path='["'+key+'"]'
 return fc
mats={}
for g,c in colors.items():
 m=bpy.data.materials.new('NEON_RGBW_'+g);m.use_nodes=True;m.diffuse_color=(*c[:3],1);p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.75,.75,.75,1);p.inputs['Roughness'].default_value=.22
 for i,ch in enumerate('RGB'):
  expr='min(1,c+w)';variables={'c':g+'_'+ch,'w':g+'_W'}
  driver(p.inputs['Emission Color'],'default_value',i,expr,variables);driver(m,'diffuse_color',i,expr,variables)
 driver(p.inputs['Emission Strength'],'default_value',None,'26*m*l',{'m':'MASTER','l':g+'_LEVEL'})
 if hasattr(m,'cycles') and hasattr(m.cycles,'use_multiple_importance_sampling'):m.cycles.use_multiple_importance_sampling=False
 m['rating_note']='Radiance is artistic; electrical rating20W/m is not converted to optical watts.';mats[g]=m
channel=bpy.data.materials.new('NEON_CHANNEL_DARK_ALUMINIUM_VISUAL');channel.diffuse_color=(.035,.04,.045,1);channel.use_nodes=True;p=channel.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.035,.04,.045,1);p.inputs['Roughness'].default_value=.4;p.inputs['Metallic'].default_value=.35
poly=D['metadata']['roof_neon_plan_polygon']
def outward(p):
 best=None
 for a,b in zip(poly,poly[1:]):
  a=Vector(a);b=Vector(b);v=b-a;h=max(0,min(1,(Vector(p[:2])-a).dot(v)/v.length_squared));q=a+h*v;dist=(Vector(p[:2])-q).length
  # Polygon is clockwise; exterior is to the left of each edge.
  n=Vector((-v.y,v.x));n.normalize()
  if best is None or dist<best[0]:best=(dist,n)
 return best[1]
def curve(name,paths,radius,mat,coll):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=radius;cu.bevel_resolution=2;cu.use_fill_caps=True
 for ps in paths:
  sp=cu.splines.new('POLY');sp.points.add(len(ps)-1)
  for p,co in zip(sp.points,ps):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);coll.objects.link(ob);cu.materials.append(mat);return ob
backs={g:[] for g in groups}
for q in L['segments']:
 g=q['group'];ps=q['points_m'];ob=curve('NEON_'+q['id'].replace('-','_'),[ps],.009,mats[g],groups[g]);ob['segment_id']=q['id'];ob['cad_handle']=q['cad_handle'];ob['group']=g;ob['cad_length_m']=q['cad_length_m'];ob['preview_pixels']=q['preview_pixel_count'];ob['cut_scenario_m']=q['cut_scenario_length_m'];ob['direction_status']=q['direction_status'];ob.visible_diffuse=False;ob.visible_shadow=False
 back=[]
 for p in ps:
  p=list(p)
  if g=='ROOF':n=outward(p);p[0]-=.012*n.x;p[1]-=.012*n.y
  elif g=='POOL':p[2]=46.499
  else:p[1]=30.552 if g=='BIG_FRAME' else 31.652
  back.append(p)
 backs[g].append(back)
for g,ps in backs.items():curve('CHANNELS_'+g,ps,.012,channel,groups[g])
# Eleven strip-light proxies provide short local spill, not one lamp per logical pixel.
# Their energies are artistic scene values and are not an equipment schedule.
def strip(name,a,b,direction,g,per_m):
 a=Vector(a);b=Vector(b);x=(b-a).normalized();z=-Vector(direction).normalized();y=z.cross(x).normalized();cd=bpy.data.lights.new('SPILL_'+name,'AREA');cd.shape='RECTANGLE';cd.size=(b-a).length;cd.size_y=.075;cd.specular_factor=0;ob=bpy.data.objects.new(cd.name,cd);groups[g].objects.link(ob);ob.location=(a+b)/2;ob.rotation_euler=Matrix((x,y,z)).transposed().to_euler();ob.visible_glossy=False
 for i,ch in enumerate('RGB'):driver(cd,'color',i,'min(1,c+w)',{'c':g+'_'+ch,'w':g+'_W'})
 driver(cd,'energy',None,str(per_m*(b-a).length)+'*m*l*s',{'m':'MASTER','l':g+'_LEVEL','s':'SPILL'});ob['emission_direction']=list(direction);ob['role']='Visual spill proxy; not a physical fixture or optical rating';return ob
for g in ['BIG_FRAME','UPPER_FRAME']:
 ps=[p for q in L['segments'] if q['group']==g for p in q['points_m']];xs=[p[0] for p in ps];zs=[p[2] for p in ps];yy=ps[0][1]+.055;x0,x1=min(xs),max(xs);z0,z1=min(zs),max(zs)
 for i,(a,b) in enumerate([((x0,yy,z0),(x1,yy,z0)),((x0,yy,z1),(x1,yy,z1)),((x0,yy,z0),(x0,yy,z1)),((x1,yy,z0),(x1,yy,z1))]):strip(g+'_'+str(i),a,b,(0,-1,0),g,1.2)
ps=[p for q in L['segments'] if q['group']=='POOL' for p in q['points_m']];x0,x1=min(p[0] for p in ps),max(p[0] for p in ps);y0,y1=min(p[1] for p in ps),max(p[1] for p in ps)
for i,(a,b) in enumerate([((x0,y0,46.45),(x1,y0,46.45)),((x0,y1,46.45),(x1,y1,46.45)),((x0,y0,46.45),(x0,y1,46.45))]):strip('POOL_'+str(i),a,b,(0,0,-1),'POOL',8.)
# Optional receiver for the direction test; it is not a modeled/surveyed pool shell.
coll=bpy.data.collections.new('POOL_RECEIVER_TEST_ONLY');s.collection.children.link(coll);bpy.ops.mesh.primitive_cube_add(size=1,location=((x0+x1)/2,(y0+y1)/2,40.335));receiver=bpy.context.object;receiver.name='POOL_FLOOR_RECEIVER_NOT_SURVEYED';receiver.dimensions=(x1-x0+.15,y1-y0+.15,.05);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
for c in list(receiver.users_collection):c.objects.unlink(receiver)
coll.objects.link(receiver);receiver.data.materials.append(bpy.data.materials['MAT_FACADE_LIGHT_VISUAL_SAMPLE']);receiver.hide_render=True;receiver.hide_viewport=True;receiver['status']='Temporary receiving surface at assumed terrace datum; not actual pool geometry; excluded from GLB'
# Use two backgrounds in one world. The environment control never changes LED channel values.
w=s.world;w.name='DAY_AND_DUSK';ns=w.node_tree.nodes;lk=w.node_tree.links;out=ns.get('World Output') or next(n for n in ns if n.type=='OUTPUT_WORLD');daybg=next(n for n in ns if n.type=='BACKGROUND');oldlink=next(l for l in list(lk) if l.to_node==out);lk.remove(oldlink)
driver(daybg.inputs['Strength'],'default_value',None,'.9*e',{'e':'ENVIRONMENT'})
night=ns.new('ShaderNodeBackground');night.name='DUSK_BACKGROUND';driver(night.inputs['Strength'],'default_value',None,'.9*e',{'e':'ENVIRONMENT'})
tc=ns.new('ShaderNodeTexCoord');sep=ns.new('ShaderNodeSeparateXYZ');lk.new(tc.outputs['Normal'],sep.inputs[0]);mp=ns.new('ShaderNodeMapRange');mp.inputs['From Min'].default_value=.1;mp.inputs['From Max'].default_value=-.8;lk.new(sep.outputs['Z'],mp.inputs[0]);ramp=ns.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.12,.035,.025,1);ramp.color_ramp.elements[1].color=(.018,.025,.07,1);lk.new(mp.outputs[0],ramp.inputs[0]);noise=ns.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5;noise.inputs['Detail'].default_value=3;lk.new(tc.outputs['Normal'],noise.inputs['Vector']);cloud=ns.new('ShaderNodeMixRGB');cloud.blend_type='MULTIPLY';cloud.inputs[0].default_value=.5;lk.new(ramp.outputs[0],cloud.inputs[1]);lk.new(noise.outputs['Fac'],cloud.inputs[2]);lk.new(cloud.outputs[0],night.inputs['Color'])
mix=ns.new('ShaderNodeMixShader');driver(mix.inputs[0],'default_value',None,'d',{'d':'DAYLIGHT'});lk.new(night.outputs[0],mix.inputs[1]);lk.new(daybg.outputs[0],mix.inputs[2]);lk.new(mix.outputs[0],out.inputs[0])
driver(bpy.data.lights['SUN'],'energy',None,'(2.4*d+.055*(1-d))*e',{'d':'DAYLIGHT','e':'ENVIRONMENT'});driver(bpy.data.lights['SOFT_SKY_FILL'],'energy',None,'(60000*d+18000*(1-d))*e',{'d':'DAYLIGHT','e':'ENVIRONMENT'});driver(s.view_settings,'exposure',None,'x',{'x':'EXPOSURE'})
logo=bpy.data.materials['MAT_SIGN_WHITE'].node_tree.nodes.get('Principled BSDF');logo.inputs['Emission Color'].default_value=(1,1,1,1);driver(logo.inputs['Emission Strength'],'default_value',None,'.15*(1-d)*e',{'d':'DAYLIGHT','e':'ENVIRONMENT'})
# Modest glow, with an exact zero setting. No huge bloom, fog or camera flare.
s.use_nodes=True;ns=s.node_tree.nodes;ns.clear();lk=s.node_tree.links;rl=ns.new('CompositorNodeRLayers');gl=ns.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='MEDIUM';gl.threshold=2.;gl.size=7;gl.mix=1.;lk.new(rl.outputs['Image'],gl.inputs['Image']);add=ns.new('CompositorNodeMixRGB');add.blend_type='ADD';driver(add.inputs[0],'default_value',None,'b',{'b':'BLOOM'});lk.new(rl.outputs['Image'],add.inputs[1]);lk.new(gl.outputs['Image'],add.inputs[2]);co=ns.new('CompositorNodeComposite');lk.new(add.outputs[0],co.inputs[0])
s.cycles.max_bounces=6;s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=2;s.cycles.transmission_bounces=2;s.cycles.use_denoising=False
# Presets are also supplied as a text block, run manually; no automatic startup code is required.
preset_code='''import bpy\nPRESET = "REFERENCE" # DAY / OFF / REFERENCE / WHITE / POOL_TEST\nc=bpy.data.objects["LIGHT_CONTROLS"]\nlevels={"ROOF":.85,"BIG_FRAME":.8,"UPPER_FRAME":.8,"POOL":0.}\ncolors={"ROOF":(.9,.015,.5,0),"BIG_FRAME":(.015,.8,.55,0),"UPPER_FRAME":(.5,.9,.035,0),"POOL":(0,0,0,0)}\nc["DAYLIGHT"]=1. if PRESET=="DAY" else 0.\nc["MASTER"]=0. if PRESET in ("DAY","OFF") else (.4 if PRESET in ("WHITE","POOL_TEST") else .65)\nc["EXPOSURE"]=.25 if PRESET=="DAY" else 0.\nc["BLOOM"]=0. if PRESET=="DAY" else .16\nfor g in levels:\n c[g+"_LEVEL"]=levels[g]\n for ch,v in zip("RGBW",colors[g]):c[g+"_"+ch]=v\n if PRESET=="WHITE":\n  c[g+"_LEVEL"]=.5\n  for ch in "RGB":c[g+"_"+ch]=0.\n  c[g+"_W"]=1.\n if PRESET=="POOL_TEST":\n  c[g+"_LEVEL"]=.6 if g=="POOL" else 0.\n  for ch in "RGB":c[g+"_"+ch]=0.\n  c[g+"_W"]=1. if g=="POOL" else 0.\nr=bpy.data.objects.get("POOL_FLOOR_RECEIVER_NOT_SURVEYED")\nif r:r.hide_render=PRESET!="POOL_TEST";r.hide_viewport=PRESET!="POOL_TEST"\nc.update_tag();bpy.context.view_layer.update()\n'''
txt=bpy.data.texts.new('LIGHT_PRESETS.py');txt.write(preset_code)
s['light_proxy_count']=11;s['logical_pixels']=1834;s['lighting_groups']='ROOF / BIG_FRAME / UPPER_FRAME / POOL';s.camera=bpy.data.objects['REFERENCE_3'];s.render.resolution_x=1280;s.render.resolution_y=1280;s.render.resolution_percentage=75;s.cycles.samples=256;s.cycles.adaptive_threshold=.02
ctrl.update_tag();bpy.context.view_layer.update();bpy.ops.wm.save_as_mainfile(filepath=str(O/'Aloft_roof_light_v07.blend'))
(O/'LIGHT_PRESETS.py').write_text(preset_code)
print('V07 roof/light file saved:61 source curves,1834 logical samples,11 spill proxies',flush=True)
