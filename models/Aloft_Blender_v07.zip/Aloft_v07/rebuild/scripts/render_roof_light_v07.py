import bpy,json,sys,time
from pathlib import Path
from mathutils import Vector
O=Path(__file__).resolve().parents[1]/'model/v07';probe='--probe' in sys.argv
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_roof_light_v07.blend'));s=bpy.context.scene;c=bpy.data.objects['LIGHT_CONTROLS']
def preset(name):exec(bpy.data.texts['LIGHT_PRESETS.py'].as_string().replace('PRESET = "REFERENCE"','PRESET = "'+name+'"'),{})
def cam(name,eye,target,lens):
 d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.location=eye;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.lens=lens;return o
roofcam=cam('ROOF_DAY_OVERVIEW',(85,-65,85),(25,16,43),52);poolcam=cam('POOL_UNDERSIDE_TEST',(-14,38,44.8),(2.5,24,43.2),43)
report={}
def render(name,camera,preset_name,res,pct):
 preset(preset_name);s.camera=camera;s.render.resolution_x,s.render.resolution_y=res;s.render.resolution_percentage=pct;s.cycles.samples=32 if probe else 256;s.cycles.adaptive_threshold=.07 if probe else .02;s.render.filepath=str(O/(name+'.png'));t=time.time();bpy.ops.render.render(write_still=True);report[name]={'seconds':round(time.time()-t,2),'resolution':[round(res[0]*pct/100),round(res[1]*pct/100)],'samples':s.cycles.samples,'preset':preset_name}
render('night_probe' if probe else 'night_hero',bpy.data.objects['REFERENCE_3'],'REFERENCE',(1280,1280),45 if probe else 75)
render('roof_day_probe' if probe else 'roof_day',roofcam,'DAY',(1200,900),50 if probe else 100)
if not probe:
 render('night_front',bpy.data.objects['REFERENCE_4'],'REFERENCE',(896,1280),100)
 render('pool_downward_test',poolcam,'POOL_TEST',(1100,850),100)
 for name,master in [('off',0.),('medium',.35),('bright',.85)]:
  preset('REFERENCE');c['MASTER']=master;c.update_tag();bpy.context.view_layer.update();s.camera=bpy.data.objects['REFERENCE_3'];s.render.resolution_x=1280;s.render.resolution_y=1280;s.render.resolution_percentage=35;s.cycles.samples=32;s.cycles.adaptive_threshold=.07;s.render.filepath=str(O/('check_'+name+'.png'));bpy.ops.render.render(write_still=True)
(O/('probe_render_report.json' if probe else 'render_report.json')).write_text(json.dumps(report,indent=2));print('Roof/light renders complete')
