from pathlib import Path
import json,csv,math,hashlib,collections
import numpy as np
from shapely.geometry import Polygon,box,Point,LineString
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
R=Path(__file__).resolve().parents[1];O=R/'model/v07';O.mkdir(exist_ok=True)
D=json.load(open(R/'model/v06/geometry_v06.json'));old=D['objects'];basehash=hashlib.sha256((R/'model/v06/geometry_v06.json').read_bytes()).hexdigest()
removed=[];retained=[]
for ob in old:
 if ob['name']=='ROOF_CANTILEVER_WITH_OPENING' or any(ob['name'].startswith(f'F{i:02}_ROOF') for i in range(1,5)):removed.append(ob['name'])
 else:
  q=dict(ob);q['name']=q['name'].replace('V06','V07');retained.append(q)
objects=retained.copy()
def put(name,V,F,mat,source):
 ids={};vs=[];rm=[]
 for p in V:
  p=tuple(round(float(x),6) for x in p)
  if p not in ids:ids[p]=len(vs);vs.append(p)
  rm.append(ids[p])
 fs=[[rm[j] for j in f] for f in F];objects.append({'name':name,'verts':vs,'faces':fs,'material_indices':[mat]*len(fs),'source':source,'status':'V07 roof visualization reconstruction authorized by engineer; unverified structural details'})
def prism(name,g,z0,z1,mat=2,source='Logical roof detail, visual dimensions'):
 V=[];F=[]
 def face(ps):k=len(V);V.extend(ps);F.append(list(range(k,k+len(ps))))
 for p in (g.geoms if hasattr(g,'geoms') else [g]):
  if p.geom_type!='Polygon' or p.area<1e-8:continue
  for t in constrained_delaunay_triangles(p).geoms:
   q=list(t.exterior.coords)[:3];face([(x,y,z1) for x,y in q]);face([(x,y,z0) for x,y in q[::-1]])
  for ring in [p.exterior]+list(p.interiors):
   ps=list(ring.coords)
   for (x,y),(u,v) in zip(ps,ps[1:]):face([(x,y,z0),(u,v,z0),(u,v,z1),(x,y,z1)])
 put(name,V,F,mat,source)
beamsets=collections.defaultdict(lambda:[[],[]])
def beam(group,a,b,w,d):
 a=np.array(a,float);b=np.array(b,float);v=(b-a)/np.linalg.norm(b-a);s=np.cross(v,[0,0,1] if abs(v[2])<.9 else [1,0,0]);s/=np.linalg.norm(s);t=np.cross(v,s);V,F=beamsets[group];k=len(V)
 for c in [a,b]:V += [list(c+s*w*i/2+t*d*j/2) for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
 F.extend([[k+i for i in f] for f in [[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]])
# Exact registration against the ORIGINAL overlaid geometry, using the source block bases.
cache=json.load(open(R/'analysis/light_source_cached.json'));lines={q['handle']:q for q in cache['lines']};fac_x0=4126992.371176859-51800.;fac_z0=220325.4867603022;plan_x0=3995641.186125229;plan_y0=234302.25705262364
rows=list(csv.DictReader(open(R/'tables/cut_review.csv',encoding='utf-8-sig')));anchors={'BIG_FRAME':('32BF3D','326FB5'),'UPPER_FRAME':('32BF79','326FF8'),'ROOF':('32BF97','326E48'),'POOL':('32BFC5','326F1A')};reg={}
for group,(copyh,origh) in anchors.items():
 p=json.loads(next(r['Вершины_CAD_мм'] for r in rows if r['CAD_Handle']==copyh))[0];q=lines[origh]['points'][0];delta=[p[0]-q[0],p[1]-q[1]];reg[group]={'copy_anchor':copyh,'original_anchor':origh,'copy_minus_original_mm':delta,'source_axes_origin_mm':[fac_x0,fac_z0] if group in ['BIG_FRAME','UPPER_FRAME'] else [plan_x0,plan_y0]}
segments=[];pixels=[];global_index=0
for r in rows:
 h=r['CAD_Handle'];hi=int(h,16);group='BIG_FRAME' if hi<=int('32BF50',16) else ('UPPER_FRAME' if hi<=int('32BF80',16) else ('POOL' if hi>=int('32BFC5',16) else 'ROOF'))
 rg=reg[group];delta=np.array(rg['copy_minus_original_mm']);origin=np.array(rg['source_axes_origin_mm']);copy=np.array(json.loads(r['Вершины_CAD_мм']));orig=copy-delta;local=(orig-origin)/1000
 matches=[]
 for e in cache['lines']:
  a=np.array(e['points'])
  if a.shape==orig.shape and min(np.max(abs(a-orig)),np.max(abs(a[::-1]-orig)))<.2:matches.append(e['handle'])
 assert matches,(group,h,'no original overlay match')
 if group in ['BIG_FRAME','UPPER_FRAME']:
  y=30.566 if group=='BIG_FRAME' else 31.666;pts=[[51.8-u,y,z] for u,z in local];axis=[0,1,0]
 else:pts=[[x,y,46.59 if group=='ROOF' else 46.486] for x,y in local];axis=[0,0,-1] if group=='POOL' else None
 L=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]));assert abs(L-float(r['Геометрия_м']))<1e-6
 n=int(r['Шагов_ближайшее_целое']);rec={'id':r['Сегмент_ID'],'cad_handle':h,'group':group,'original_overlay_aliases':matches,'points_m':pts,'cad_length_m':L,'preview_pixel_count':n,'cut_scenario_length_m':n*.1667,'cut_scenario_delta_mm':(n*.1667-L)*1000,'emission_axis':axis,'direction_status':'CAD vertex order for preview; signal chain direction/ports unconfirmed'};segments.append(rec)
 edges=[math.dist(a,b) for a,b in zip(pts,pts[1:])];cums=np.r_[0,np.cumsum(edges)]
 for i in range(n):
  dist=(i+.5)*L/n;j=min(len(edges)-1,int(np.searchsorted(cums,dist,side='right')-1));t=(dist-cums[j])/edges[j];p=np.array(pts[j])*(1-t)+np.array(pts[j+1])*t
  pixels.append({'preview_index':global_index,'pixel_id':f'{rec["id"]}:P{i+1:03}','segment_id':rec['id'],'group':group,'local_index':i,'distance_from_start_m':dist,'position_m':p.tolist(),'sampling_pitch_m':L/n,'sampling_status':'Even visual sampling of source length; 166.7mm cut compatibility not approved'});global_index+=1
# Roof perimeter follows the registered roof plan. The unlit east edge is closed structurally only.
rooflines=[s for s in segments if s['group']=='ROOF'];P=Polygon([(-1.8,31.65),(52.19992,31.65),(52.38374,-.6),(37.04974,-.6),(37.04974,13.45),(18.14983,13.45),(18.14983,15.6),(-1.8,15.6)])
assert P.is_valid;cap=P.buffer(-.014,join_style='mitre');hole=box(.25,18.5,7.415,29.6);roof=cap.difference(hole)
prism('ROOF_CANTILEVER_WITH_OPENING',roof,46.51,46.65,2,'Reconstructed continuous G roof; CAD neon plan registration controls edge, visual thickness')
prism('ROOF_CONTINUOUS_SOFFIT',roof,46.50,46.51,0,'Continuous underside around glazed opening; pool strip mounted below at46.486')
prism('ROOF_CONTINUOUS_FASCIA',cap.difference(cap.buffer(-.14,join_style='mitre')),46.07,46.50,2)
prism('ROOF_SKYLIGHT_PERIMETER_FRAME',hole.buffer(.10,join_style='mitre').difference(hole.buffer(-.07,join_style='mitre')),46.5,46.72,2)
ys=[18.5,21.275,24.05,26.825,29.6]
for i,(a,b) in enumerate(zip(ys,ys[1:])):prism('ROOF_SKYLIGHT_GLASS_'+str(i),box(.295,a+.04,7.37,b-.04),46.595,46.615,9,'Logical transparent skylight; visual reconstruction, no glazing/structure specification')
for y in ys[1:-1]:beam('ROOF_SKYLIGHT_BEARING_MULLIONS',(.18,y,46.555),(7.485,y,46.555),.07,.11)
# Supported louver cassettes. No blades extend across the terrace/skylight opening.
cassettes=[('FRONT',(19.05,31.47),(52.12,31.47),[44.95+i*.225 for i in range(6)]),('REAR_WEST',(9.6,15.70),(18.15,15.70),[43.575+i*.3 for i in range(8)]),('REAR_MIDDLE',(18.15,13.56),(37.05,13.56),[43.575+i*.3 for i in range(8)]),('REAR_EAST',(37.05,-.48),(52.36,-.48),[43.575+i*.3 for i in range(8)]),('COURTYARD_RETURN',(37.16,-.48),(37.16,13.45),[43.575+i*.3 for i in range(8)])]
for name,a,b,zs in cassettes:
 for z in zs:beam('ROOF_LOUVRE_CASSETTE_'+name,(*a,z),(*b,z),.22,.095)
 N=max(1,math.ceil(math.dist(a,b)/3))
 for j in range(N+1):
  p=np.array(a)+(np.array(b)-a)*j/N;beam('ROOF_LOUVRE_SUPPORTS_'+name,(*p,min(zs)-.08),(*p,46.51),.06,.06)
for name,(V,F) in beamsets.items():put(name,V,F,2,'Continuous supported cassette / skylight frame; visual structural arrangement authorized by engineer')
for s in segments:
 if s['group']=='ROOF':
  for p in s['points_m']:assert P.buffer(.005).covers(Point(p[:2])),(s['id'],p)
 if s['group']=='POOL':
  for p in s['points_m']:assert roof.buffer(.04).covers(Point(p[:2])),(s['id'],'pool strip unsupported',p)
summary={g:{'segments':sum(s['group']==g for s in segments),'cad_length_m':sum(s['cad_length_m'] for s in segments if s['group']==g),'preview_pixels':sum(s['preview_pixel_count'] for s in segments if s['group']==g)} for g in anchors}
assert len(segments)==61 and len(pixels)==1834 and len({p['pixel_id'] for p in pixels})==1834
meta=dict(D['metadata']);meta.update(accepted_base='V06 approved by engineer',accepted_base_geometry_sha256=basehash,roof_reconstruction_authorized=True,roof_source_registration=reg,roof_removed_old_objects=removed,roof_neon_plan_polygon=list(P.exterior.coords));meta['roof_surface']=[{'exterior':list(cap.exterior.coords),'holes':[list(hole.exterior.coords)]}];meta['visual_assumptions']=meta['visual_assumptions']+[['V07 roof','Continuous cap, soffit, fascia, framed glazed opening and supported louvers','Explicit user authorization to reconstruct roof; not structural calculation'],['Neon section','Approximate 18mm luminous diffuser /24mm channel','VISUAL estimate; actual product dimensions unconfirmed'],['Neon profiles','Source lengths and XY/Z projections registered without scaling; mounting offset and roof Z visual','CAD registration + visual depth'],['Pool receiver','Optional temporary plane for downward-light test, not surveyed pool geometry','VISUAL TEST ONLY']]
(O/'geometry_v07.json').write_text(json.dumps({'objects':objects,'metadata':meta},ensure_ascii=False,separators=(',',':')));(O/'visual_assumptions.json').write_text(json.dumps(meta['visual_assumptions'],ensure_ascii=False,indent=2))
lighting={'status':'First RGBW visualization, electrical routing/photometry not approved','registration':reg,'summary':summary,'segments':segments,'excluded_duplicate_copy_handle':'32BF51','cut_pitch_m_approx':.1667,'confirmed_rating_W_per_m':20,'confirmed_voltage_V':48,'confirmed_pixels_per_m':6,'white_chromaticity':'Neutral preview, no CCT claim','segment_vertex_direction':'Unconfirmed signal chain, preserved CAD order','pixel_sampling':'Nearest cut-step count per source polyline, evenly distributed for visualization; not a final cut map'}
(O/'lighting_geometry.json').write_text(json.dumps(lighting,ensure_ascii=False,indent=2));(O/'pixel_map.json').write_text(json.dumps(pixels,ensure_ascii=False,separators=(',',':')))
with (O/'pixel_map.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['PreviewIndex','PixelID','SourceSegmentID','Group','LocalIndex','X_m','Y_m','Z_m','VisualPitch_m','Status'])
 for p in pixels:w.writerow([p['preview_index'],p['pixel_id'],p['segment_id'],p['group'],p['local_index'],*p['position_m'],p['sampling_pitch_m'],'PREVIEW ONLY; signal direction and cut compatibility unconfirmed'])
with (O/'lighting_segments.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['SegmentID','CADHandle','Group','CADLength_m','PreviewPixels','CutScenario_m','Delta_mm','Electrical_20W_m_W','Status'])
 for s in segments:w.writerow([s['id'],s['cad_handle'],s['group'],s['cad_length_m'],s['preview_pixel_count'],s['cut_scenario_length_m'],s['cut_scenario_delta_mm'],s['cut_scenario_length_m']*20,'PRELIMINARY, not equipment or port schedule'])
print('Roof meshes',len(objects),'removed',len(removed),'lighting',json.dumps(summary),flush=True)
