import bpy
from pathlib import Path
from mathutils import Vector

O=Path(__file__).resolve().parents[1]/'model/v07'
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_roof_light_v07.blend'))
s=bpy.context.scene
for name,eye,target,lens in [('ROOF_DAY_OVERVIEW',(85,-65,85),(25,16,43),52),('POOL_UNDERSIDE_TEST',(-14,38,44.8),(2.5,24,43.2),43)]:
 ob=bpy.data.objects.get(name)
 if ob is None:
  ob=bpy.data.objects.new(name,bpy.data.cameras.new(name));s.collection.objects.link(ob)
 ob.location=eye;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler();ob.data.lens=lens
for filename,textname in [('README_RU.md','README_RU'),('visual_assumptions.json','READ_ME_VISUAL_ASSUMPTIONS')]:
 t=bpy.data.texts.get(textname) or bpy.data.texts.new(textname);t.clear();t.write((O/filename).read_text())
exec(bpy.data.texts['LIGHT_PRESETS.py'].as_string(),{})
s.camera=bpy.data.objects['REFERENCE_3']
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   sp=area.spaces.active;sp.shading.color_type='MATERIAL';sp.clip_end=1000;sp.region_3d.view_perspective='CAMERA'
bpy.ops.object.select_all(action='DESELECT')
c=bpy.data.objects['LIGHT_CONTROLS'];c.select_set(True);bpy.context.view_layer.objects.active=c
bpy.ops.wm.save_as_mainfile(filepath=str(O/'Aloft_roof_light_v07.blend'))
# glTF exports meshes; convert only temporary copies of the 65 curve objects.
dg=bpy.context.evaluated_depsgraph_get();copies=[]
for ob in list(s.objects):
 if ob.type=='CURVE' and (ob.name.startswith('NEON_SEG_') or ob.name.startswith('CHANNELS_')):
  mesh=bpy.data.meshes.new_from_object(ob.evaluated_get(dg),depsgraph=dg)
  clone=bpy.data.objects.new(ob.name+'_EXPORT',mesh);s.collection.objects.link(clone);clone.matrix_world=ob.matrix_world.copy()
  for key in ob.keys():clone[key]=ob[key]
  copies.append(clone)
assert len(copies)==65
bpy.ops.object.select_all(action='DESELECT')
for ob in list(bpy.data.collections['ALMAZOV_ARCHITECTURE_V07'].objects)+copies:ob.select_set(True)
bpy.context.view_layer.objects.active=bpy.data.objects['BUILDING_WING_ENVELOPE_V07']
bpy.ops.export_scene.gltf(filepath=str(O/'Aloft_roof_light_v07.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False,export_extras=True)
print('Final native file saved, static GLB exported with 61 source neon meshes and 4 channels',flush=True)
