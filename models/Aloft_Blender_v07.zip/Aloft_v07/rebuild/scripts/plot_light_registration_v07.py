import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

O=Path(__file__).resolve().parents[1]/'model/v07'
L=json.load(open(O/'lighting_geometry.json'));D=json.load(open(O/'geometry_v07.json'))
fig,(front,roof)=plt.subplots(1,2,figsize=(13,7),layout='constrained')
colors={'ROOF':'#c14baf','BIG_FRAME':'#008e82','UPPER_FRAME':'#6a971b','POOL':'#2768b1'}
for q in L['segments']:
 ps=q['points_m'];g=q['group']
 if g in ('BIG_FRAME','UPPER_FRAME'):
  front.plot([51.8-p[0] for p in ps],[p[2] for p in ps],color=colors[g],lw=2.2)
 else:roof.plot([p[0] for p in ps],[p[1] for p in ps],color=colors[g],lw=2.2)
front.set(xlabel='Фасадная ось u, м',ylabel='Высота Z, м',title='Главный фасад: исходные линии DWG',xlim=(-2,54),ylim=(0,49))
roof.add_patch(Polygon(D['metadata']['roof_neon_plan_polygon'],facecolor='#e8e8ec',edgecolor='#7f8390',lw=1,zorder=-2))
roof.add_patch(Polygon(D['metadata']['roof_opening'],facecolor='white',edgecolor='#7f8390',lw=.8,zorder=-1))
roof.set(xlabel='Ось X модели, м',ylabel='Ось Y модели, м',title='Кровля: розовый контур + синий П-контур снизу',xlim=(-4,55),ylim=(-3,35))
for ax in [front,roof]:
 ax.set_aspect('equal');ax.grid(alpha=.17);ax.spines[['top','right']].set_visible(False)
front.text(1,3,'Большая рама: 98,6401 м / 20 участков\nВерхняя: 40,0008 м / 8 участков',fontsize=9)
roof.text(1,1,'Кромка: 138,0035 м / 28 участков\nБассейн: 29,0300 м / 5 участков',fontsize=9)
fig.suptitle('Aloft V07 — регистрация 61 участка, без масштабирования и повторного учёта копий',fontsize=13)
fig.savefig(O/'light_registration.svg');fig.savefig(O/'light_registration.png',dpi=130);plt.close(fig)
