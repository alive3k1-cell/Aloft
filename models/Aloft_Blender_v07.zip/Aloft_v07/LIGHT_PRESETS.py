import bpy
PRESET = "REFERENCE" # DAY / OFF / REFERENCE / WHITE / POOL_TEST
c=bpy.data.objects["LIGHT_CONTROLS"]
levels={"ROOF":.85,"BIG_FRAME":.8,"UPPER_FRAME":.8,"POOL":0.}
colors={"ROOF":(.9,.015,.5,0),"BIG_FRAME":(.015,.8,.55,0),"UPPER_FRAME":(.5,.9,.035,0),"POOL":(0,0,0,0)}
c["DAYLIGHT"]=1. if PRESET=="DAY" else 0.
c["MASTER"]=0. if PRESET in ("DAY","OFF") else (.4 if PRESET in ("WHITE","POOL_TEST") else .65)
c["EXPOSURE"]=.25 if PRESET=="DAY" else 0.
c["BLOOM"]=0. if PRESET=="DAY" else .16
for g in levels:
 c[g+"_LEVEL"]=levels[g]
 for ch,v in zip("RGBW",colors[g]):c[g+"_"+ch]=v
 if PRESET=="WHITE":
  c[g+"_LEVEL"]=.5
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1.
 if PRESET=="POOL_TEST":
  c[g+"_LEVEL"]=.6 if g=="POOL" else 0.
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1. if g=="POOL" else 0.
r=bpy.data.objects.get("POOL_FLOOR_RECEIVER_NOT_SURVEYED")
if r:r.hide_render=PRESET!="POOL_TEST";r.hide_viewport=PRESET!="POOL_TEST"
c.update_tag();bpy.context.view_layer.update()
