import bpy,bmesh,json,math,time,sys,random
from pathlib import Path
from mathutils import Vector,Matrix
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];O=R/'model/v06';D=json.load(open(O/'geometry_v06.json'));preview='--preview' in sys.argv or '--all-preview' in sys.argv;allpreview='--all-preview' in sys.argv;start=time.time()
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1;s['status']='V06 architectural visualization: source-derived measured outlines with user-authorized, explicitly unverified visual depth estimates. Not construction documentation.'
s['pool']='Roof underside to pool floor, per engineer. Pool world placement and electrical design not approved.'
arch=bpy.data.collections.new('ALMAZOV_ARCHITECTURE_V06');s.collection.children.link(arch);site=bpy.data.collections.new('ILLUSTRATIVE_SITE_NOT_SURVEYED');s.collection.children.link(site)
def material(name,color,rough=.6,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
mats=[material('MAT_FACADE_LIGHT_VISUAL_SAMPLE',(.78,.79,.80),.52),material('MAT_GLASS',(.025,.037,.048),.10),material('MAT_ROOF_PAINTED_METAL',(.36,.37,.38),.4,.22),material('MAT_FACADE_GREY_LIGHT',(.51,.53,.55),.58),material('MAT_FACADE_GREY_MEDIUM',(.35,.37,.39),.6),material('MAT_FACADE_DARK_PLINTH',(.18,.19,.20),.65),material('MAT_TERRACOTTA_REFERENCE_SAMPLE',(.43,.145,.075),.38),material('MAT_ALUMINIUM_DARK',(.045,.055,.065),.3,.45),material('MAT_SIGN_WHITE',(.9,.9,.88),.36),material('MAT_RAIL_GLASS',(.70,.78,.82),.06),material('MAT_CANOPY_CYAN_REFERENCE',(.06,.32,.44),.4),material('MAT_CANOPY_YELLOW_REFERENCE',(.62,.47,.07),.4),material('MAT_CANOPY_MAGENTA_REFERENCE',(.43,.08,.25),.4),material('MAT_CANOPY_GREEN_REFERENCE',(.26,.42,.08),.4)]
p=mats[1].node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.10;p.inputs['Roughness'].default_value=.055;p.inputs['IOR'].default_value=1.48;p.inputs['Specular IOR Level'].default_value=.65
p=mats[9].node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.95;p.inputs['IOR'].default_value=1.46
# Fine panel joints are a visual material setting, not claimed mounting dimensions.
for idx in [0,3,4,5]:
 m=mats[idx];ns=m.node_tree.nodes;lk=m.node_tree.links;p=ns.get('Principled BSDF');geo=ns.new('ShaderNodeNewGeometry');pos=ns.new('ShaderNodeSeparateXYZ');normal=ns.new('ShaderNodeSeparateXYZ');lk.new(geo.outputs['Position'],pos.inputs[0]);lk.new(geo.outputs['Normal'],normal.inputs[0])
 ab=ns.new('ShaderNodeMath');ab.operation='ABSOLUTE';lk.new(normal.outputs['X'],ab.inputs[0]);mix=ns.new('ShaderNodeMixRGB');mix.blend_type='MIX';lk.new(ab.outputs[0],mix.inputs[0]);lk.new(pos.outputs['X'],mix.inputs[1]);lk.new(pos.outputs['Y'],mix.inputs[2]);vals=[]
 for out,period in [(mix.outputs[0],.6),(pos.outputs['Z'],1.2)]:
  scale=ns.new('ShaderNodeMath');scale.operation='DIVIDE';scale.inputs[1].default_value=period;lk.new(out,scale.inputs[0]);frac=ns.new('ShaderNodeMath');frac.operation='FRACT';lk.new(scale.outputs[0],frac.inputs[0]);edge=ns.new('ShaderNodeMath');edge.operation='LESS_THAN';edge.inputs[1].default_value=.003/period;lk.new(frac.outputs[0],edge.inputs[0]);vals.append(edge.outputs[0])
 maximum=ns.new('ShaderNodeMath');maximum.operation='MAXIMUM';lk.new(vals[0],maximum.inputs[0]);lk.new(vals[1],maximum.inputs[1]);bump=ns.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.18;bump.inputs['Distance'].default_value=.001;lk.new(maximum.outputs[0],bump.inputs['Height']);lk.new(bump.outputs[0],p.inputs['Normal'])
metrics=[]
for obdata in D['objects']:
 me=bpy.data.meshes.new(obdata['name']);me.from_pydata(obdata['verts'],[],obdata['faces']);me.update();ob=bpy.data.objects.new(obdata['name'],me);arch.objects.link(ob)
 for m in mats:me.materials.append(m)
 for f,idx in zip(me.polygons,obdata['material_indices']):f.material_index=idx
 ob['source']=obdata['source'];ob['status']=obdata['status'];bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me)
 non=sum(not e.is_manifold for e in bm.edges);metrics.append({'name':ob.name,'faces':len(me.polygons),'nonmanifold_edges':non,'role':'primary' if ob.name.startswith('BUILDING_WING') else 'detail'});bm.free()
 if ob.name.startswith('BUILDING_WING'):assert non==0,metrics[-1]
def mesh(name,vs,fs,mat,coll=site):
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new(name,me);coll.objects.link(ob);ob.data.materials.append(mat);return ob
def cube(name,center,size,mat,coll=site):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);ob=bpy.context.object;ob.name=name;ob.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 for c in list(ob.users_collection):c.objects.unlink(ob)
 coll.objects.link(ob);ob.data.materials.append(mat);return ob
# Brand contours originate in the supplied drawing. No alternate font is substituted.
logo=json.load(open(O/'logo_reconstructed.json'));vs=[];fs=[]
from mathutils.geometry import tessellate_polygon
# Logo triangles are generated outside Blender from exact source contours.
LG=json.load(open(O/'logo_mesh.json'));lo=mesh('ALOFТ_DWG_VECTOR_SIGN',LG['verts'],LG['faces'],mats[8],arch);lo['source']=logo['status'];lo['repairs']=logo['repairs'];lo['official_brand_asset_verified']=False
# A second instance uses identical glyph proportions at the entrance.
entry=bpy.data.objects.new('ENTRANCE_SIGN_DWG_PROPORTIONS',lo.data);arch.objects.link(entry);entry.scale=(.45,.45,.45);entry.location=(45.0,18.45,-19.1);entry['status']='Visual placement and scale, not an approved sign schedule'
# Illustrative context. No street map or survey is inferred.
asphalt=material('PRESENTATION_ASPHALT',(.075,.08,.085),.95);concrete=material('PRESENTATION_CONCRETE',(.48,.49,.50),.85);grass=material('PRESENTATION_GRASS',(.11,.22,.035),.95)
cube('ASPHALT_GROUND',(26,15,-1.62),(240,220,.24),asphalt)
# Measured-plan terrace deck rings exported as presentation meshes only.
SITE=json.load(open(O/'site_meshes.json'))
for q in SITE:mesh(q['name'],q['verts'],q['faces'],concrete)
cube('FRONT_GRASS_STRIP',(26,36,-1.45),(74,2.2,.12),grass)
for x in range(-6,67,7):
 cube('PAVING_WALKWAY',(x,34.5,-1.40),(6.9,1.0,.18),concrete)
# A small reusable tree mesh is instanced throughout the background; no heavy plant library is imported.
bark=material('TREE_BARK',(.12,.07,.035),.95);leafmats=[material('LEAF_'+str(i),c,.85) for i,c in enumerate([(.08,.19,.025),(.13,.27,.035),(.20,.34,.06)])]
def tree_prototype(seed):
 rng=random.Random(seed);V=[];F=[];MI=[]
 def cylinder(a,b,r):
  a=Vector(a);b=Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,1,0))).normalized();y=z.cross(x);k=len(V)
  for c,rr in [(a,r),(b,r*.45)]:
   for j in range(7):V.append(tuple(c+rr*(x*math.cos(j*2*math.pi/7)+y*math.sin(j*2*math.pi/7))))
  for j in range(7):F.append((k+j,k+(j+1)%7,k+(j+1)%7+7,k+j+7));MI.append(0)
 cylinder((0,0,0),(0,0,7),.2)
 for cl in range(22):
  phi=rng.uniform(0,2*math.pi);rad=rng.uniform(.7,3.2);center=Vector((math.cos(phi)*rad,math.sin(phi)*rad,rng.uniform(6.3,10.0)));cylinder((0,0,rng.uniform(3.5,6.5)),center,.065)
  for j in range(180):
   p=center+Vector((rng.gauss(0,.8),rng.gauss(0,.8),rng.gauss(0,.65)));n=Vector((rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1))).normalized();x=n.cross(Vector((0,0,1)))
   if x.length<.01:x=Vector((1,0,0))
   x.normalize();y=n.cross(x);l=rng.uniform(.15,.30);w=l*.45;k=len(V);V.extend([tuple(p-x*l/2),tuple(p-y*w/2),tuple(p+x*l/2),tuple(p+y*w/2)]);F.append((k,k+1,k+2,k+3));MI.append(1+rng.randrange(3))
 me=bpy.data.meshes.new('TREE_SHARED_'+str(seed));me.from_pydata(V,[],F);me.update()
 for m in [bark]+leafmats:me.materials.append(m)
 for p,i in zip(me.polygons,MI):p.material_index=i
 return me
prototypes=[tree_prototype(31),tree_prototype(79)]
positions=[(x,-18) for x in [-22,-10,2,15,29,43,58,72]]+[(-18,y) for y in [-2,13,28,44]]+[(75,-2),(75,14)]
for i,(x,y) in enumerate(positions):
 ob=bpy.data.objects.new('PRESENTATION_TREE_'+str(i),prototypes[i%2]);site.objects.link(ob);ob.location=(x,y,-1.5);scale=.8+(i%4)*.12;ob.scale=(scale,scale,scale);ob.rotation_euler[2]=i*.7
# Low shrubs share leaf geometry at smaller scale.
for i,x in enumerate(range(-5,69,6)):
 ob=bpy.data.objects.new('PRESENTATION_SHRUB_'+str(i),prototypes[i%2]);site.objects.link(ob);ob.location=(x,36,-2.35);ob.scale=(.20,.20,.14)
# Day sky with broad cloud reflections; no image is projected onto the facade.
w=bpy.data.worlds.new('DAYLIGHT_CLOUDS');s.world=w;w.use_nodes=True;n=w.node_tree.nodes;l=w.node_tree.links;n.clear();out=n.new('ShaderNodeOutputWorld');bg=n.new('ShaderNodeBackground');bg.inputs['Strength'].default_value=.9;tc=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=12;noise.inputs['Detail'].default_value=3.2;noise.inputs['Roughness'].default_value=.65;l.new(tc.outputs['Normal'],noise.inputs['Vector']);ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.39;ramp.color_ramp.elements[0].color=(.23,.43,.73,1);ramp.color_ramp.elements[1].position=.62;ramp.color_ramp.elements[1].color=(.92,.94,.97,1);l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs['Color'],bg.inputs['Color']);l.new(bg.outputs[0],out.inputs[0])
ld=bpy.data.lights.new('SUN','SUN');ld.energy=2.4;ld.angle=math.radians(2.2);sun=bpy.data.objects.new('SUN',ld);s.collection.objects.link(sun);sun.rotation_euler=(Vector((25,15,20))-Vector((85,85,105))).to_track_quat('-Z','Y').to_euler()
ld=bpy.data.lights.new('SOFT_SKY_FILL','AREA');ld.energy=60000;ld.size=45;ld.specular_factor=0;fill=bpy.data.objects.new('SOFT_SKY_FILL',ld);s.collection.objects.link(fill);fill.visible_glossy=False;fill.location=(-30,30,65);fill.rotation_euler=(Vector((25,15,20))-fill.location).to_track_quat('-Z','Y').to_euler()
# Fit cameras use the actual orange frame landmarks from the two reference JPGs.
cameras=[];camera_checks=[]
for num in [5,4,3,2,1,6]:
 c=json.load(open(O/f'camera_reference{num}.json'));r=c['rotation_world_to_cv'];p=c['camera_position_m'];cd=bpy.data.cameras.new('REFERENCE_'+str(num));ob=bpy.data.objects.new('REFERENCE_'+str(num),cd);s.collection.objects.link(ob);ob.matrix_world=Matrix([[r[0][0],-r[1][0],-r[2][0],p[0]],[r[0][1],-r[1][1],-r[2][1],p[1]],[r[0][2],-r[1][2],-r[2][2],p[2]],[0,0,0,1]])
 W,H=c['resolution'];cd.sensor_fit='HORIZONTAL';cd.sensor_width=36
 if c.get('camera_type')=='ORTHO':cd.type='ORTHO';cd.ortho_scale=c['ortho_scale']*W/H
 else:
  cd.lens=c['focal_pixels']*36/W;cd.shift_x=(W/2-c['principal_point'][0])/W;cd.shift_y=(c['principal_point'][1]-H/2)/W
 cd.clip_end=1000;cameras.append((num,ob));ob['calibration_status']=c['status'];ob['reference_landmark_rmse_px']=c['landmark_rmse_px']
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.use_denoising=False;s.cycles.samples=24 if preview else 96;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.08 if preview else .04;s.cycles.adaptive_min_samples=8 if preview else 16;s.cycles.max_bounces=6;s.cycles.transmission_bounces=4;s.cycles.glossy_bounces=3;s.render.threads_mode='FIXED';s.render.threads=4;s.render.resolution_x=896;s.render.resolution_y=1280;s.render.resolution_percentage=50 if preview else 100;s.render.image_settings.file_format='PNG';s.view_settings.view_transform='AgX';s.view_settings.exposure=.25
s.camera=cameras[0][1]
for num,cam in cameras:
 c=json.load(open(O/f'camera_reference{num}.json'));ps=[];W,H=c['resolution'];s.render.resolution_x=W;s.render.resolution_y=H
 for pt in c['matched_world_points']:
  q=world_to_camera_view(s,cam,Vector(pt));ps.append([q.x*W,(1-q.y)*H])
 err=max(math.dist(a,b) for a,b in zip(ps,c['reprojected_points']));camera_checks.append({'reference':num,'blender_vs_calibrated_projection_max_px':err,'reference_landmark_rmse_px':c['landmark_rmse_px']});assert err<.2,camera_checks[-1]
text=bpy.data.texts.new('READ_ME_VISUAL_ASSUMPTIONS');text.write(json.dumps(D['metadata']['visual_assumptions'],ensure_ascii=False,indent=2)+'\nLogo: '+logo['status']+'\nIllustrative landscaping is not a surveyed site. Cycles PBR daylight is not a lux calculation.')
s.render.resolution_x=896;s.render.resolution_y=1280
for a in bpy.context.screen.areas if bpy.context.screen else []:
 if a.type=='VIEW_3D':a.spaces.active.region_3d.view_perspective='CAMERA'
bpy.ops.wm.save_as_mainfile(filepath=str(O/'Aloft_visual_v06.blend'))
if not preview:
 bpy.ops.object.select_all(action='DESELECT')
 for ob in arch.objects:ob.select_set(True)
 bpy.context.view_layer.objects.active=next(iter(arch.objects));bpy.ops.export_scene.gltf(filepath=str(O/'Aloft_visual_v06.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False,export_extras=True)
report={'status':'VISUALIZATION V06, not construction documentation','objects':len(arch.objects),'metrics':metrics,'camera_checks':camera_checks,'render_engine':'Cycles CPU','render_resolution':[448,640] if preview else [896,1280],'render_resolution_by_view':{str(n):json.load(open(O/f'camera_reference{n}.json'))['resolution'] for n,cam in cameras},'view_transform':'AgX','exposure':.25,'samples_max':s.cycles.samples,'adaptive_threshold':s.cycles.adaptive_threshold,'render_seconds':{},'site':'Illustrative only, instanced tree meshes; excluded from GLB','logo':logo['status']}
for num,cam in (cameras if allpreview or not preview else cameras[:1]):
 s.camera=cam;c=json.load(open(O/f'camera_reference{num}.json'));s.render.resolution_x,s.render.resolution_y=c['resolution'];s.render.filepath=str(O/(f'preview_ref{num}.png' if preview else f'final_ref{num}.png'));st=time.time();bpy.ops.render.render(write_still=True);report['render_seconds'][str(num)]=round(time.time()-st,2)
report['build_seconds']=round(time.time()-start,2);(O/('preview_validation.json' if preview else 'visual_validation.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print('V06 visual build complete',flush=True)
