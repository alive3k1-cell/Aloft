import bpy
from pathlib import Path
O=Path(__file__).resolve().parents[1]/'model/v08'
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_light_show_v08.blend'))
t=bpy.data.texts.get('README_RU') or bpy.data.texts.new('README_RU');t.clear();t.write((O/'README_RU.md').read_text())
bpy.ops.wm.save_as_mainfile(filepath=str(O/'Aloft_light_show_v08.blend'))
