import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Vector

R=Path(__file__).resolve().parents[1];B=R/'model/v07';O=R/'model/v08';O.mkdir(exist_ok=True)
L=json.load(open(B/'lighting_geometry.json'));P=json.load(open(B/'pixel_map.json'))
bpy.ops.wm.open_mainfile(filepath=str(B/'Aloft_roof_light_v07.blend'))
s=bpy.context.scene;c=bpy.data.objects['LIGHT_CONTROLS']
s['version']='V08: animated RGBW visualization, unchanged accepted architecture and roof from V07'
s['lighting_status']='Native shader animation; visual pixel order is not wiring or controller addressing'
def prop(k,v,lo,hi,description):
 c[k]=v;c.id_properties_ui(k).update(min=lo,max=hi,soft_min=lo,soft_max=hi,description=description)
prop('MODE',2,0,3,'0 — исходный статичный; 1 — плавная смена цвета; 2 — волна; 3 — бегущий свет')
prop('SPEED',1.,.05,4.,'1 — полный цикл за 8 секунд при24 кадрах/с')
prop('COLOR_AMOUNT',.5,0.,1.,'Доля изменения цвета в волне и плавной смене цвета')
prop('WAVE_DEPTH',.65,0.,1.,'Глубина мягкой волны яркости')
prop('CHASE_WIDTH',.22,.05,.5,'Ширина плавного бегущего пятна, доля контура')
prop('POOL_EFFECTS',0,0,1,'0 — бассейн постоянный;1 — участвует в эффектах')
c['POOL_R']=0.;c['POOL_G']=0.;c['POOL_B']=0.;c['POOL_W']=1.;c['POOL_LEVEL']=.22
c['preview_order']='Geometric order for effects only. No signal direction, ports or DMX addresses assigned.'
def drv(target,attr,expr,props,index=None):
 f=target.driver_add(attr,index) if index is not None else target.driver_add(attr);d=f.driver;d.type='SCRIPTED';d.expression=expr
 for name,key in props.items():
  v=d.variables.new();v.name=name;v.type='SINGLE_PROP';v.targets[0].id=c;v.targets[0].data_path='["'+key+'"]'
def path_phase(point,path):
 lens=[(b-a).length for a,b in zip(path,path[1:])];total=sum(lens);best=None;cum=0.
 for a,b,le in zip(path,path[1:],lens):
  h=max(0.,min(1.,(point-a).dot(b-a)/(le*le)));q=a+(b-a)*h;dist=(point-q).length_squared
  if best is None or dist<best[0]:best=(dist,(cum+h*le)/total)
  cum+=le
 return best[1]
def trajectory(g):
 pts=[p for q in L['segments'] if q['group']==g for p in q['points_m']]
 x0,x1=min(p[0] for p in pts),max(p[0] for p in pts)
 if g in ('BIG_FRAME','UPPER_FRAME'):
  y=pts[0][1];z0,z1=min(p[2] for p in pts),max(p[2] for p in pts)
  return [Vector(p) for p in [(x1,y,z1),(x0,y,z1),(x0,y,z0),(x1,y,z0),(x1,y,z1)]]
 if g=='POOL':
  y0,y1=min(p[1] for p in pts),max(p[1] for p in pts);z=pts[0][2]
  return [Vector(p) for p in [(x1,y1,z),(x0,y1,z),(x0,y0,z),(x1,y0,z)]]
 return [Vector((x,y,46.59)) for x,y in [(52.19992,31.65),(-1.8,31.65),(-1.8,15.6),(18.14983,15.6),(18.14983,13.45),(37.04974,13.45),(37.04974,-.6),(52.38374,-.6)]]
paths={g:trajectory(g) for g in L['summary']}
coll=bpy.data.collections.new('ANIMATED_DIFFUSERS_V08');s.collection.children.link(coll)
pixel_by_segment={q['id']:[p for p in P if p['segment_id']==q['id']] for q in L['segments']}
phase_records=[]
for seg in L['segments']:
 old=bpy.data.objects['NEON_'+seg['id'].replace('-','_')];old.hide_render=True;old.hide_viewport=True;old['role']='Hidden original source curve; visible diffuser is PIXELS_'+seg['id']
 ps=[Vector(p) for p in seg['points_m']];edges=[(b-a).length for a,b in zip(ps,ps[1:])];cums=[0.]
 for d in edges:cums.append(cums[-1]+d)
 count=seg['preview_pixel_count'];length=cums[-1]
 rawstops=sorted(set([i*length/count for i in range(count+1)]+cums));stops=[]
 for d in rawstops:
  if not stops or d-stops[-1]>1e-6:stops.append(d)
 # Vertices include every CAD corner, even when a pixel spans that corner.
 def locate(d):
  j=next((i for i,v in enumerate(cums[1:]) if d<=v+1e-9),len(edges)-1)
  return ps[j]+(ps[j+1]-ps[j])*max(0.,min(1.,(d-cums[j])/edges[j]))
 centers=[locate(d) for d in stops];verts=[];faces=[];facepixels=[]
 for i,center in enumerate(centers):
  tangent=centers[min(i+1,len(centers)-1)]-centers[max(0,i-1)];tangent.normalize()
  ref=Vector((0,0,1)) if abs(tangent.z)<.9 else Vector((0,1,0));u=tangent.cross(ref).normalized();v=tangent.cross(u).normalized()
  for j in range(8):
   co=center+.009*(u*math.cos(j*math.tau/8)+v*math.sin(j*math.tau/8));verts.append(tuple(co))
 for i,(a,b) in enumerate(zip(stops,stops[1:])):
  pi=min(count-1,int(((a+b)/2)/length*count))
  for j in range(8):faces.append([i*8+j,i*8+(j+1)%8,(i+1)*8+(j+1)%8,(i+1)*8+j]);facepixels.append(pi)
 faces.append(list(range(7,-1,-1)));facepixels.append(0)
 faces.append(list(range((len(centers)-1)*8,len(centers)*8)));facepixels.append(count-1)
 mesh=bpy.data.meshes.new('PIXELS_'+seg['id']);mesh.from_pydata(verts,[],faces);mesh.update()
 ob=bpy.data.objects.new('PIXELS_'+seg['id'],mesh);coll.objects.link(ob);mesh.materials.append(bpy.data.materials['NEON_RGBW_'+seg['group']]);ob.visible_diffuse=False;ob.visible_shadow=False
 for k in ['segment_id','cad_handle','group','cad_length_m','preview_pixels']:ob[k]=old[k]
 attr=mesh.attributes.new('PATH_PHASE','FLOAT','FACE');index=mesh.attributes.new('PREVIEW_INDEX','INT','FACE')
 local=pixel_by_segment[seg['id']];phases=[path_phase(Vector(p['position_m']),paths[seg['group']]) for p in local]
 for f,pi in enumerate(facepixels):attr.data[f].value=phases[pi];index.data[f].value=local[pi]['preview_index'];mesh.polygons[f].use_smooth=len(mesh.polygons[f].vertices)==4
 for p,phase in zip(local,phases):phase_records.append({'pixel_id':p['pixel_id'],'preview_index':p['preview_index'],'segment_id':p['segment_id'],'group':seg['group'],'position_m':p['position_m'],'effect_phase':phase,'status':'Geometric visual phase only, not wiring/address direction'})

for g in L['summary']:
 m=bpy.data.materials['NEON_RGBW_'+g];ns=m.node_tree.nodes;lk=m.node_tree.links;p=ns.get('Principled BSDF')
 for i in range(3):p.inputs['Emission Color'].driver_remove('default_value',i)
 p.inputs['Emission Strength'].driver_remove('default_value')
 def value(name,number=None,expression=None,props=None):
  n=ns.new('ShaderNodeValue');n.name=name;n.label=name
  if number is not None:n.outputs[0].default_value=number
  if expression is not None:drv(n.outputs[0],'default_value',expression,props)
  return n.outputs[0]
 def mathnode(op,a,b=None):
  n=ns.new('ShaderNodeMath');n.operation=op
  for i,q in enumerate([a,b] if b is not None else [a]):
   if isinstance(q,(int,float)):n.inputs[i].default_value=q
   else:lk.new(q,n.inputs[i])
  return n.outputs[0]
 base=ns.new('ShaderNodeCombineRGB');base.name='BASE_RGB'
 for i,ch in enumerate('RGB'):drv(base.inputs[i],'default_value','v',{'v':g+'_'+ch})
 white=ns.new('ShaderNodeCombineRGB');white.name='INDEPENDENT_W'
 for i in range(3):drv(white.inputs[i],'default_value','v',{'v':g+'_W'})
 phase=ns.new('ShaderNodeAttribute');phase.attribute_name='PATH_PHASE';phase.name='GEOMETRIC_PATH_PHASE'
 time=value('CYCLE_TIME',expression='(frame-1)/192*s',props={'s':'SPEED'})
 effvars={'k':'MODE'}
 suffix='*p' if g=='POOL' else ''
 if g=='POOL':effvars['p']='POOL_EFFECTS'
 waveon=value('WAVE_ENABLED',expression='(1 if k==2 else 0)'+suffix,props=effvars)
 chaseon=value('CHASE_ENABLED',expression='(1 if k==3 else 0)'+suffix,props=effvars)
 hueon=value('HUE_ENABLED',expression='(1 if k==1 or k==2 else 0)*a'+suffix,props={**effvars,'a':'COLOR_AMOUNT'})
 dist=mathnode('SUBTRACT',phase.outputs['Fac'],time)
 wav=mathnode('ADD',mathnode('MULTIPLY',mathnode('SINE',mathnode('MULTIPLY',dist,math.tau*2)),.5),.5)
 depth=value('WAVE_DEPTH',expression='v',props={'v':'WAVE_DEPTH'})
 wave=mathnode('SUBTRACT',1,mathnode('MULTIPLY',mathnode('MULTIPLY',mathnode('SUBTRACT',1,wav),depth),waveon))
 centered=mathnode('ABSOLUTE',mathnode('SUBTRACT',mathnode('FRACT',mathnode('ADD',dist,.5)),.5))
 width=value('CHASE_WIDTH',expression='v',props={'v':'CHASE_WIDTH'})
 chase=mathnode('ADD',.08,mathnode('MULTIPLY',mathnode('POWER',mathnode('MAXIMUM',0,mathnode('SUBTRACT',1,mathnode('DIVIDE',centered,width))),2),.92))
 chasefactor=mathnode('ADD',1,mathnode('MULTIPLY',mathnode('SUBTRACT',chase,1),chaseon))
 strength=value('MASTER_LEVEL',expression='26*m*l',props={'m':'MASTER','l':g+'_LEVEL'})
 lk.new(mathnode('MULTIPLY',strength,mathnode('MULTIPLY',wave,chasefactor)),p.inputs['Emission Strength'])
 hue=ns.new('ShaderNodeHueSaturation');hue.inputs['Saturation'].default_value=1.;hue.inputs['Value'].default_value=1.
 huephase=mathnode('ADD',time,mathnode('MULTIPLY',phase.outputs['Fac'],mathnode('MULTIPLY',waveon,.65)))
 hueoffset=mathnode('MULTIPLY',mathnode('SINE',mathnode('MULTIPLY',huephase,math.tau)),mathnode('MULTIPLY',hueon,.4))
 lk.new(mathnode('ADD',.5,hueoffset),hue.inputs['Hue']);lk.new(base.outputs[0],hue.inputs['Color'])
 add=ns.new('ShaderNodeMixRGB');add.name='RGB_PLUS_INDEPENDENT_WHITE';add.blend_type='ADD';add.use_clamp=True;add.inputs[0].default_value=1.;lk.new(hue.outputs[0],add.inputs[1]);lk.new(white.outputs[0],add.inputs[2]);lk.new(add.outputs[0],p.inputs['Emission Color'])
 m['effect_note']='FACE attribute samples at6/m preview count; neutral W is added after RGB hue effects'
# Existing coarse spill proxies track mode-average intensity, rather than adding1834 lamps.
for ob in s.objects:
 if ob.type=='LIGHT' and ob.name.startswith('SPILL_'):
  fc=ob.data.animation_data.drivers.find('energy');d=fc.driver;d.expression='('+d.expression+')*(1 if k==0 or k==1 else .55)'
  v=d.variables.new();v.name='k';v.type='SINGLE_PROP';v.targets[0].id=c;v.targets[0].data_path='["MODE"]'
s.frame_start=1;s.frame_end=192;s.render.fps=24;s.render.fps_base=1.;s.frame_set(1);s.render.use_persistent_data=True
s.timeline_markers.new('START — Space: play light wave',frame=1);s.timeline_markers.new('HALF CYCLE',frame=97)
for name in ['README_RU','READ_ME_VISUAL_ASSUMPTIONS']:
 if name in bpy.data.texts:bpy.data.texts[name].name=name+'_V07_SOURCE'
presets='''import bpy
PRESET = "WAVE" # REFERENCE / WAVE / CHASE / COLOR_FADE / WHITE / POOL / OFF / DAY
c=bpy.data.objects["LIGHT_CONTROLS"]
c["MODE"]={"WAVE":2,"CHASE":3,"COLOR_FADE":1}.get(PRESET,0)
c["MASTER"]=0. if PRESET in ("OFF","DAY") else .65
c["DAYLIGHT"]=1. if PRESET=="DAY" else 0.
c["EXPOSURE"]=.25 if PRESET=="DAY" else 0.
c["BLOOM"]=0. if PRESET=="DAY" else .16
c["SPEED"]=1.;c["COLOR_AMOUNT"]=.5;c["WAVE_DEPTH"]=.65;c["CHASE_WIDTH"]=.22;c["POOL_EFFECTS"]=0
colors={"ROOF":(.9,.015,.5,0),"BIG_FRAME":(.015,.8,.55,0),"UPPER_FRAME":(.5,.9,.035,0),"POOL":(0,0,0,1)}
levels={"ROOF":.85,"BIG_FRAME":.8,"UPPER_FRAME":.8,"POOL":.22 if PRESET in ("WAVE","CHASE","COLOR_FADE") else 0.}
for g in colors:
 for ch,v in zip("RGBW",colors[g]):c[g+"_"+ch]=v
 c[g+"_LEVEL"]=levels[g]
 if PRESET=="WHITE":
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1.;c[g+"_LEVEL"]=.45
 if PRESET=="POOL":
  c[g+"_LEVEL"]=.5 if g=="POOL" else 0.
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1. if g=="POOL" else 0.
r=bpy.data.objects["POOL_FLOOR_RECEIVER_NOT_SURVEYED"]
r.hide_render=PRESET!="POOL";r.hide_viewport=PRESET!="POOL"
c.update_tag();bpy.context.scene.frame_set(1);bpy.context.view_layer.update()
'''
txt=bpy.data.texts['LIGHT_PRESETS.py'];txt.clear();txt.write(presets);(O/'LIGHT_PRESETS.py').write_text(presets)
if (O/'README_RU.md').exists():t=bpy.data.texts.new('README_RU');t.write((O/'README_RU.md').read_text())
s.camera=bpy.data.objects['REFERENCE_4'];bpy.ops.object.select_all(action='DESELECT');c.select_set(True);bpy.context.view_layer.objects.active=c
for scr in bpy.data.screens:
 for area in scr.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
c.update_tag();bpy.context.view_layer.update()
assert len(phase_records)==1834 and len({p['pixel_id'] for p in phase_records})==1834
(O/'effect_pixel_map.json').write_text(json.dumps(sorted(phase_records,key=lambda p:p['preview_index']),ensure_ascii=False,separators=(',',':')))
bpy.ops.wm.save_as_mainfile(filepath=str(O/'Aloft_light_show_v08.blend'))
print('V08 saved:61 animated diffuser meshes,1834 preview samples; architecture retained',flush=True)
