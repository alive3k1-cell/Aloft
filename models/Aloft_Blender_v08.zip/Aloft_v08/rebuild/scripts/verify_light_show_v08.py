import bpy,json,hashlib,math,struct
from pathlib import Path

R=Path(__file__).resolve().parents[1];B=R/'model/v07';O=R/'model/v08'
def geometry_digest(ob):
 h=hashlib.sha256();h.update(ob.type.encode());h.update(bytes(str(list(ob.matrix_world)),encoding='utf8'))
 if ob.type=='MESH':
  for v in ob.data.vertices:h.update(struct.pack('<3f',*v.co))
  for p in ob.data.polygons:h.update(struct.pack('<I',len(p.vertices)));h.update(struct.pack('<'+'I'*len(p.vertices),*p.vertices));h.update(struct.pack('<I',p.material_index))
  h.update('|'.join(m.name for m in ob.data.materials).encode())
 elif ob.type=='CURVE':
  h.update(str(ob.data.bevel_depth).encode())
  for sp in ob.data.splines:
   for p in sp.points:h.update(struct.pack('<4f',*p.co))
 return h.hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(B/'Aloft_roof_light_v07.blend'))
arch={ob.name:geometry_digest(ob) for ob in bpy.data.collections['ALMAZOV_ARCHITECTURE_V07'].objects}
guides={ob.name:geometry_digest(ob) for ob in bpy.context.scene.objects if ob.name.startswith('NEON_SEG_')}
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_light_show_v08.blend'))
newarch={ob.name:geometry_digest(ob) for ob in bpy.data.collections['ALMAZOV_ARCHITECTURE_V07'].objects};assert arch==newarch
newguides={ob.name:geometry_digest(ob) for ob in bpy.context.scene.objects if ob.name.startswith('NEON_SEG_')};assert guides==newguides and len(guides)==61
for name in guides:assert bpy.data.objects[name].hide_render and bpy.data.objects[name].hide_viewport
pixelmeshes=list(bpy.data.collections['ANIMATED_DIFFUSERS_V08'].objects);assert len(pixelmeshes)==61
source=json.load(open(B/'pixel_map.json'));effect=json.load(open(O/'effect_pixel_map.json'))
assert len(effect)==1834 and len({p['pixel_id'] for p in effect})==1834
for a,b in zip(source,effect):
 assert all(a[k]==b[k] for k in ['pixel_id','preview_index','segment_id','group','position_m'])
 assert 0<=b['effect_phase']<=1
indices=set()
for ob in pixelmeshes:
 assert ob.type=='MESH' and len(ob.data.polygons)>2
 ids={v.value for v in ob.data.attributes['PREVIEW_INDEX'].data};indices|=ids
 assert len(ids)==ob['preview_pixels']
 assert len(ob.data.attributes['PATH_PHASE'].data)==len(ob.data.polygons)
 assert ob.data.materials[0].node_tree.nodes.get('GEOMETRIC_PATH_PHASE').attribute_name=='PATH_PHASE'
assert indices==set(range(1834))
s=bpy.context.scene;c=bpy.data.objects['LIGHT_CONTROLS'];saved={k:c[k] for k in c.keys()}
def update(f):c.update_tag();s.frame_set(f);bpy.context.view_layer.update()
def val(g,n):return bpy.data.materials['NEON_RGBW_'+g].node_tree.nodes[n].outputs[0].default_value
groups=['ROOF','BIG_FRAME','UPPER_FRAME','POOL']
for mode in range(4):
 c['MODE']=mode;update(49)
 for g in groups:
  assert abs(val(g,'CYCLE_TIME')-.25)<1e-6
  expected=0. if g=='POOL' else 1.
  assert abs(val(g,'WAVE_ENABLED')-(expected if mode==2 else 0))<1e-7
  assert abs(val(g,'CHASE_ENABLED')-(expected if mode==3 else 0))<1e-7
  assert abs(val(g,'HUE_ENABLED')-(expected*.5 if mode in (1,2) else 0))<1e-7
update(1);assert abs(val('ROOF','CYCLE_TIME'))<1e-7
update(193);assert abs(val('ROOF','CYCLE_TIME')-1.)<1e-7
# All periodic operations are sin(2pi*t), sin(4pi*t) or frac(phase-t).
for phase in [.01,.125,.4,.8,.99]:
 for t in [0.,.125,.75]:
  wave=lambda x:1-.65*(1-(.5+.5*math.sin(math.tau*2*(phase-x))))
  chase=lambda x:.08+.92*max(0,1-abs(((phase-x+.5)%1)-.5)/.22)**2
  assert abs(wave(t)-wave(t+1))<1e-12 and abs(chase(t)-chase(t+1))<1e-12
c['MASTER']=0.;update(25)
for g in groups:assert abs(val(g,'MASTER_LEVEL'))<1e-7
for ob in s.objects:
 if ob.type=='LIGHT' and ob.name.startswith('SPILL_'):assert abs(ob.data.energy)<1e-7
c['MASTER']=.65;update(25);before=val('ROOF','MASTER_LEVEL');c['ENVIRONMENT']=2.;update(25);assert val('ROOF','MASTER_LEVEL')==before
for ch in 'RGB':c['ROOF_'+ch]=0.
c['ROOF_W']=1.;update(25);ns=bpy.data.materials['NEON_RGBW_ROOF'].node_tree.nodes
assert all(abs(i.default_value)<1e-7 for i in ns['BASE_RGB'].inputs)
assert all(abs(i.default_value-1)<1e-7 for i in ns['INDEPENDENT_W'].inputs)
assert ns['RGB_PLUS_INDEPENDENT_WHITE'].inputs[2].links[0].from_node==ns['INDEPENDENT_W']
c['POOL_EFFECTS']=1;c['MODE']=2;update(49);assert val('POOL','WAVE_ENABLED')==1
for k,v in saved.items():c[k]=v
update(1)
assert s.frame_start==1 and s.frame_end==192 and s.render.fps==24
assert not any(im.source=='FILE' and not im.packed_file for im in bpy.data.images)
text=bpy.data.texts['LIGHT_PRESETS.py'].as_string();assert all(p in text for p in ['REFERENCE','WAVE','CHASE','COLOR_FADE','WHITE','POOL','OFF','DAY'])
assert c['MODE']==2 and c['POOL_EFFECTS']==0
report={'version':'V08','native_reopened':True,'architecture_and_roof_meshes_unchanged_from_V07':len(arch),'source_curve_geometry_unchanged':len(guides),'source_guides_hidden':True,'animated_diffuser_meshes':len(pixelmeshes),'unique_original_preview_pixel_ids':len(indices),'original_pixel_positions_unchanged':True,'all_four_modes_driver_checked':True,'independent_W_added_after_RGB_effect':True,'pool_effects_independent':True,'master_zero_disables_neon_and_spill':True,'environment_does_not_change_neon_level':True,'cycle_frames':[1,192],'fps':24,'period_seconds_at_speed_1':8,'period_boundary_math_checked':True,'external_textures_required':False,'hardware_addressing':'Not assigned; geometric visual phases only','photometry':'Art-directed radiance and coarse spill, no lux/IES calculation'}
(O/'validation_v08.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
