import bpy,json,time,sys
from pathlib import Path

R=Path(__file__).resolve().parents[1];O=R/'model/v08';probe='--probe' in sys.argv;cliponly='--clip-only' in sys.argv
bpy.ops.wm.open_mainfile(filepath=str(O/'Aloft_light_show_v08.blend'));s=bpy.context.scene;c=bpy.data.objects['LIGHT_CONTROLS'];s.camera=bpy.data.objects['REFERENCE_4'];s.render.use_persistent_data=True
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.cycles.use_animated_seed=False
report=json.load(open(O/'render_report.json')) if cliponly and (O/'render_report.json').exists() else {}
def preset(name):exec(bpy.data.texts['LIGHT_PRESETS.py'].as_string().replace('PRESET = "WAVE"','PRESET = "'+name+'"'),{})
def render(name,frame=1,samples=64,res=(640,914)):
 s.frame_set(frame);s.render.resolution_x,s.render.resolution_y=res;s.render.resolution_percentage=100;s.cycles.samples=samples;s.cycles.adaptive_threshold=.035 if samples>=64 else .08;s.render.filepath=str(O/(name+'.png'));t=time.time();bpy.ops.render.render(write_still=True);report[name]={'seconds':round(time.time()-t,3),'frame':frame,'mode':c['MODE'],'resolution':list(res),'samples':samples}
if probe:
 preset('WAVE');render('wave_probe',49,16,(384,548))
else:
 if not cliponly:
  for name,p,frame in [('reference','REFERENCE',1),('wave','WAVE',49),('chase','CHASE',49)]:
   preset(p);render(name,frame)
 preset('WAVE');(O/'frames').mkdir(exist_ok=True)
 # Standard two-pass composite: render the static scene once in scene-linear EXR,
 # then render emissive geometry with real primary-ray occlusion on each frame.
 # Moving reflections and pixel-by-pixel spill are available in the native file;
 # this short preview keeps the background and coarse group spill fixed.
 s.use_nodes=False;s.frame_set(1);s.render.resolution_x=448;s.render.resolution_y=640;s.cycles.samples=64;s.cycles.adaptive_threshold=.035
 emitters=list(bpy.data.collections['ANIMATED_DIFFUSERS_V08'].objects)
 if not cliponly:
  for ob in emitters:ob.hide_render=True
  s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='16';s.render.image_settings.exr_codec='ZIP';s.render.filepath=str(O/'backplate.exr')
  bpy.ops.render.render(write_still=True)
  for ob in emitters:ob.hide_render=False
 for name in ['ALMAZOV_ARCHITECTURE_V07','ILLUSTRATIVE_SITE_NOT_SURVEYED']:bpy.context.view_layer.layer_collection.children[name].holdout=True
 occ=bpy.data.collections.new('CHANNEL_HOLDOUT');s.collection.children.link(occ)
 for ob in list(s.objects):
  if ob.name.startswith('CHANNELS_'):
   for coll in list(ob.users_collection):coll.objects.unlink(ob)
   occ.objects.link(ob)
  if ob.type=='LIGHT':ob.hide_render=True
 bpy.context.view_layer.layer_collection.children[occ.name].holdout=True
 black=bpy.data.worlds.new('OVERLAY_BLACK');black.use_nodes=True;black.node_tree.nodes.get('Background').inputs['Strength'].default_value=0.;s.world=black;s.render.film_transparent=True
 s.cycles.max_bounces=0;s.cycles.diffuse_bounces=0;s.cycles.glossy_bounces=0;s.cycles.transmission_bounces=0
 s.use_nodes=True;ns=s.node_tree.nodes;ns.clear();lk=s.node_tree.links
 rl=ns.new('CompositorNodeRLayers');back=ns.new('CompositorNodeImage');back.image=bpy.data.images.load(str(O/'backplate.exr'))
 over=ns.new('CompositorNodeAlphaOver');over.inputs[0].default_value=1.;lk.new(back.outputs['Image'],over.inputs[1]);lk.new(rl.outputs['Image'],over.inputs[2])
 gl=ns.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='MEDIUM';gl.threshold=2.;gl.size=7;gl.mix=1.;lk.new(over.outputs[0],gl.inputs['Image'])
 add=ns.new('CompositorNodeMixRGB');add.blend_type='ADD';add.inputs[0].default_value=c['BLOOM'];lk.new(over.outputs[0],add.inputs[1]);lk.new(gl.outputs[0],add.inputs[2]);co=ns.new('CompositorNodeComposite');lk.new(add.outputs[0],co.inputs[0])
 s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8'
 for n,f in enumerate(range(1,193,3)):
  render('frames/frame_'+str(n).zfill(4),f,64,(448,640))
(O/('probe_render_report.json' if probe else 'render_report.json')).write_text(json.dumps(report,indent=2))
print('V08 renders complete',flush=True)
