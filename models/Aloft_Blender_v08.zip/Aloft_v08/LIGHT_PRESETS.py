import bpy
PRESET = "WAVE" # REFERENCE / WAVE / CHASE / COLOR_FADE / WHITE / POOL / OFF / DAY
c=bpy.data.objects["LIGHT_CONTROLS"]
c["MODE"]={"WAVE":2,"CHASE":3,"COLOR_FADE":1}.get(PRESET,0)
c["MASTER"]=0. if PRESET in ("OFF","DAY") else .65
c["DAYLIGHT"]=1. if PRESET=="DAY" else 0.
c["EXPOSURE"]=.25 if PRESET=="DAY" else 0.
c["BLOOM"]=0. if PRESET=="DAY" else .16
c["SPEED"]=1.;c["COLOR_AMOUNT"]=.5;c["WAVE_DEPTH"]=.65;c["CHASE_WIDTH"]=.22;c["POOL_EFFECTS"]=0
colors={"ROOF":(.9,.015,.5,0),"BIG_FRAME":(.015,.8,.55,0),"UPPER_FRAME":(.5,.9,.035,0),"POOL":(0,0,0,1)}
levels={"ROOF":.85,"BIG_FRAME":.8,"UPPER_FRAME":.8,"POOL":.22 if PRESET in ("WAVE","CHASE","COLOR_FADE") else 0.}
for g in colors:
 for ch,v in zip("RGBW",colors[g]):c[g+"_"+ch]=v
 c[g+"_LEVEL"]=levels[g]
 if PRESET=="WHITE":
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1.;c[g+"_LEVEL"]=.45
 if PRESET=="POOL":
  c[g+"_LEVEL"]=.5 if g=="POOL" else 0.
  for ch in "RGB":c[g+"_"+ch]=0.
  c[g+"_W"]=1. if g=="POOL" else 0.
r=bpy.data.objects["POOL_FLOOR_RECEIVER_NOT_SURVEYED"]
r.hide_render=PRESET!="POOL";r.hide_viewport=PRESET!="POOL"
c.update_tag();bpy.context.scene.frame_set(1);bpy.context.view_layer.update()
